from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_page, name='landing'),  
    path('education/', views.education_page, name='education'),
    path('resources/', views.resources_page, name='resources'),

    path('assessment/step1/', views.assessment_step1, name='assessment_step1'),
    path('assessment/step2/', views.assessment_step2, name='assessment_step2'),
    path('assessment/step3/', views.assessment_step3, name='assessment_step3'),

    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('otp-verify/', views.otp_login_view, name='otp_verify'),
    path('resend-otp/', views.resend_otp_view, name='resend_otp'),

    path('forgot-password/', views.forgot_password_request, name='forgot_password'),
    path('forgot-password/verify/', views.forgot_password_verify, name='forgot_password_verify'),
    path('forgot-password/reset/', views.forgot_password_reset, name='forgot_password_reset'),

    path('history/', views.history_view, name='history'),
]