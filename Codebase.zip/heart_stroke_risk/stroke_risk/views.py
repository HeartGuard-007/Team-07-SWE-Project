import os
import joblib
import numpy as np
import random
from django.shortcuts import render, redirect
from django.core.mail import send_mail
from django.utils import timezone
from django.utils.dateformat import format as date_format
from django.contrib.auth import get_user_model
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from .forms import StrokeRiskForm, RegisterForm
from .models import PredictionHistory

model_path = os.path.join(os.path.dirname(__file__), 'ml_model', 'stroke_model.pkl')
model = joblib.load(model_path)

otp_storage = {}

def send_otp_email(user, purpose="login"):
    otp = random.randint(100000, 999999)
    expiry = timezone.now() + timezone.timedelta(minutes=2)

    otp_storage[user.username] = {'otp': str(otp), 'expires': expiry}

    subject = 'Your OTP - Stroke Risk System'
    if purpose == "login":
        message = f"""
Hi {user.username},

Your OTP for login is: {otp}
This OTP will expire in 2 minutes.
"""
    else:
        message = f"""
Hi {user.username},

Your OTP to reset your password is: {otp}
This OTP will expire in 2 minutes.
"""

    send_mail(subject, message, None, [user.email])

def preprocess_input(data):
    gender_map = {'Male': 1, 'Female': 0, 'Other': 2}
    ever_married_map = {'Yes': 1, 'No': 0}
    work_type_map = {'Private': 0, 'Self-employed': 1, 'Govt_job': 2, 'children': 3, 'Never_worked': 4}
    residence_type_map = {'Urban': 1, 'Rural': 0}
    smoking_status_map = {'formerly smoked': 0, 'never smoked': 1, 'smokes': 2, 'Unknown': 3}

    return [
        gender_map.get(data.get('gender', 'Male'), 0),
        float(data.get('age', 0)),
        int(data.get('hypertension', 0)),
        int(data.get('heart_disease', 0)),
        ever_married_map.get(data.get('ever_married', 'No'), 0),
        work_type_map.get(data.get('work_type', 'Private'), 0),
        residence_type_map.get(data.get('residence_type', 'Urban'), 1),
        float(data.get('avg_glucose_level', 0)),
        float(data.get('bmi', 0)),
        smoking_status_map.get(data.get('smoking_status', 'Unknown'), 3),
    ]

def register_view(request):
    if request.session.get('username'):
        return redirect('assessment_step1')
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.session.get('username'):
        return redirect('landing')
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = get_user_model().objects.filter(username=username).first()
        if user and user.check_password(password):
            send_otp_email(user, purpose="login")
            request.session['otp_user'] = username
            return redirect('otp_verify')
        else:
            return render(request, 'login.html', {'error': 'Invalid username or password.'})
    return render(request, 'login.html')

def otp_login_view(request):
    if request.method == 'POST':
        otp_input = request.POST.get('otp')
        username = request.session.get('otp_user')
        otp_data = otp_storage.get(username)
        if otp_data and otp_data['otp'] == otp_input and timezone.now() < otp_data['expires']:
            request.session['username'] = username
            del otp_storage[username]
            del request.session['otp_user']
            return redirect('landing')
        else:
            return render(request, 'otp_verify.html', {'error': 'Invalid or expired OTP.'})
    return render(request, 'otp_verify.html')

def logout_view(request):
    request.session.flush()
    return redirect('login')

@csrf_exempt
def assessment_step1(request):
    if not request.session.get('username'):
        return redirect('login')

    previous_data = request.session.get('step1', {})

    if request.method == "POST":
        request.session['step1'] = {
            "age": request.POST.get("age"),
            "gender": request.POST.get("gender"),
            "ever_married": request.POST.get("ever_married"),
            "residence_type": request.POST.get("residence_type"),
        }
        return redirect("assessment_step2")

    return render(request, "assessment_step1.html", {"step1": previous_data})

@csrf_exempt
def assessment_step2(request):
    if not request.session.get('username'):
        return redirect('login')
    step2_data = request.session.get('step2', {})

    if request.method == "POST":
        if request.POST.get("previous"):
            request.session['step2'] = {
                "hypertension": request.POST.get("hypertension"),
                "heart_disease": request.POST.get("heart_disease"),
                "avg_glucose_level": request.POST.get("avg_glucose_level"),
                "bmi": request.POST.get("bmi"),
            }
            return redirect("assessment_step1")
        
        request.session['step2'] = {
            "hypertension": request.POST.get("hypertension"),
            "heart_disease": request.POST.get("heart_disease"),
            "avg_glucose_level": request.POST.get("avg_glucose_level"),
            "bmi": request.POST.get("bmi"),
        }
        return redirect("assessment_step3")
    
    return render(request, "assessment_step2.html", {"step2": step2_data})


@csrf_exempt
def assessment_step3(request):
    if not request.session.get('username'):
        return redirect('login')

    previous_data = request.session.get('step3', {})

    if request.method == "POST":
        request.session['step3'] = {
            "work_type": request.POST.get("work_type"),
            "smoking_status": request.POST.get("smoking_status"),
        }

        if "previous" in request.POST:
            return redirect('assessment_step2')

        step1 = request.session.get("step1", {})
        step2 = request.session.get("step2", {})
        step3 = request.session.get("step3", {})

        input_data = {
            **step1,
            **step2,
            **step3,
            "avg_glucose_level": step2.get("avg_glucose_level", 0),
            "bmi": float(step2.get("bmi", 0))
        }

        input_array = np.array([preprocess_input(input_data)])
        probability = model.predict_proba(input_array)[0][1]
        probability_percent = round(probability * 100, 2)

        if probability_percent < 30:
            risk_level = "Low Risk"
        elif probability_percent < 60:
            risk_level = "Moderate Risk"
        else:
            risk_level = "High Risk"

        user = get_user_model().objects.get(username=request.session.get('username'))
        PredictionHistory.objects.create(
            user=user,
            result_percent=probability_percent,
            result_label=risk_level
        )

        return render(request, "result.html", {
            "risk_percent": probability_percent,
            "risk_label": risk_level,
            "bmi_value": input_data["bmi"],
            "bmi_status": "Overweight" if input_data["bmi"] >= 25 else "Normal",
            "bp_status": "High" if int(step2.get("systolic", 0)) > 140 else "Normal",
            "glucose_value": input_data["avg_glucose_level"],
            "glucose_status": "High" if float(step2.get("avg_glucose_level", 0)) > 140 else "Normal",
            "cholesterol_status": step2.get("cholesterol", "Unknown"),
            "recommendations": [
                "Exercise at least 30 minutes daily",
                "Reduce sugar intake",
                "Get regular medical checkups"
            ],
        })

    return render(request, "assessment_step3.html", {"step3": previous_data})

def education_page(request):
    return render(request, 'education.html')

def history_view(request):
    if not request.session.get('username'):
        return redirect('login')
    user = get_user_model().objects.get(username=request.session.get('username'))
    history = PredictionHistory.objects.filter(user=user).order_by('-created_at')
    labels = [date_format(h.created_at, 'Y-m-d H:i') for h in history]
    values = [h.result_percent for h in history]
    return render(request, 'history.html', {
        'history': history,
        'username': user.username,
        'graph_labels': labels,
        'graph_values': values,
    })

def resend_otp_view(request):
    username = request.session.get('otp_user') or request.session.get('reset_user')
    if username:
        try:
            user = get_user_model().objects.get(username=username)
            purpose = "login" if 'otp_user' in request.session else "reset"
            send_otp_email(user, purpose=purpose)
            return JsonResponse({'success': True, 'message': 'OTP resent successfully.'})
        except get_user_model().DoesNotExist:
            return JsonResponse({'success': False, 'message': 'User not found.'})
    return JsonResponse({'success': False, 'message': 'Session expired. Please login again.'})


def forgot_password_request(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        user = get_user_model().objects.filter(email=email).first()
        if user:
            send_otp_email(user, purpose="reset")
            request.session['reset_user'] = user.username
            return redirect('forgot_password_verify')
        else:
            return render(request, 'forgot_password_request.html', {'error': 'Email not found.'})
    return render(request, 'forgot_password_request.html')

def forgot_password_verify(request):
    if request.method == 'POST':
        otp_input = request.POST.get('otp')
        username = request.session.get('reset_user')
        otp_data = otp_storage.get(username)
        if otp_data and otp_data['otp'] == otp_input and timezone.now() < otp_data['expires']:
            del otp_storage[username]
            return redirect('forgot_password_reset')
        else:
            return render(request, 'forgot_password_verify.html', {'error': 'Invalid or expired OTP.'})
    return render(request, 'forgot_password_verify.html')

def forgot_password_reset(request):
    username = request.session.get('reset_user')
    if not username:
        return redirect('login')
    if request.method == 'POST':
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')
        if new_password != confirm_password:
            return render(request, 'forgot_password_reset.html', {'error': 'Passwords do not match.'})
        user = get_user_model().objects.get(username=username)
        user.set_password(new_password)
        user.save()
        del request.session['reset_user']
        return redirect('login')
    return render(request, 'forgot_password_reset.html')

def resources_page(request):
    return render(request, 'resources.html', {'username': request.session.get('username')})

def home_page(request):
    return render(request, 'index.html')

from django.contrib.auth import logout
from django.shortcuts import redirect

def logout_view(request):
    logout(request)
    return redirect('login') 