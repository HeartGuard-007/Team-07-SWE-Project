# stroke_risk/forms.py

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class StrokeRiskForm(forms.Form):
    gender = forms.ChoiceField(choices=[('Male', 'Male'), ('Female', 'Female'), ('Other', 'Other')])
    age = forms.FloatField()
    hypertension = forms.ChoiceField(choices=[(0, 'No'), (1, 'Yes')])
    heart_disease = forms.ChoiceField(choices=[(0, 'No'), (1, 'Yes')])
    ever_married = forms.ChoiceField(choices=[('No', 'No'), ('Yes', 'Yes')])
    work_type = forms.ChoiceField(choices=[
        ('Private', 'Private'),
        ('Self-employed', 'Self-employed'),
        ('Govt_job', 'Govt_job'),
        ('children', 'Children'),
        ('Never_worked', 'Never_worked'),
    ])
    residence_type = forms.ChoiceField(choices=[('Urban', 'Urban'), ('Rural', 'Rural')])
    avg_glucose_level = forms.FloatField()
    bmi = forms.FloatField()
    smoking_status = forms.ChoiceField(choices=[
        ('never smoked', 'Never smoked'),
        ('formerly smoked', 'Formerly smoked'),
        ('smokes', 'Smokes'),
        ('Unknown', 'Unknown'),
    ])

class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ["username", "email", "password1", "password2"]
