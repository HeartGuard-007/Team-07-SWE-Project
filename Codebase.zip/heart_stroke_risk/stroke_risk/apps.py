from django.apps import AppConfig


class StrokeRiskConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'stroke_risk'
