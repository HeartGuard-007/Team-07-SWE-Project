from django.db import models
from django.contrib.auth.models import User

class PredictionHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    gender = models.CharField(max_length=10, default="Unknown")
    age = models.FloatField(default=0.0)
    hypertension = models.IntegerField(default=0)
    heart_disease = models.IntegerField(default=0)
    ever_married = models.CharField(max_length=5, default="No")
    work_type = models.CharField(max_length=20, default="Unknown")
    residence_type = models.CharField(max_length=10, default="Unknown")
    avg_glucose_level = models.FloatField(default=0.0)
    bmi = models.FloatField(default=0.0)
    smoking_status = models.CharField(max_length=20, default="Unknown")
    result_percent = models.FloatField(default=0.0)
    result_label = models.CharField(max_length=20, default="Unknown")
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"{self.user.username} - {self.result_label} ({self.result_percent}%)"
